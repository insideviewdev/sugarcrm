<?php
function pre_install()
{
	global $current_user;
	

	require_once('include/utils.php');
	require_once('include/utils/file_utils.php');
	require_once('config.php');
	require_once('include/database/PearDatabase.php');

	require_once('include/MVC/Controller/SugarController.php');
	require_once('modules/ModuleBuilder/controller.php');
	require_once('modules/ModuleBuilder/parsers/ParserFactory.php');

	echo"<br><h4>You can <strong>safely ignore</strong> if there are <strong>any errors</strong> during the installation</h4><br>";

	// We will try to get the parameters required for autoProvisining and later append it to the Iframe URL.
	$autoProvisionParam = '';
	$autoProvisionParam .= '&crm_org_id={php} global $sugar_config; echo $sugar_config[\'unique_key\'];{/php}';
	//$autoProvisionParam .= '&crm_session_id={php} $sessionId= session_id(); echo $sessionId; {/php}';
	$autoProvisionParam .= '&crm_user_firstname={php}global $current_user; echo $current_user->first_name; {/php}';
	$autoProvisionParam .= '&crm_user_lastname={php} echo $current_user->last_name;{/php}';
	$autoProvisionParam .= '&crm_user_email={php} echo $current_user->email1;{/php}';
	$autoProvisionParam .= '&crm_user_phone={php} echo $current_user->phone_work;{/php}';
	$autoProvisionParam .= '&crm_user_street={php} echo $current_user->address_street;{/php}';
	$autoProvisionParam .= '&crm_user_city={php} echo $current_user->address_city;{/php}';
	$autoProvisionParam .= '&crm_user_state={php} echo $current_user->address_state;{/php}';
	$autoProvisionParam .= '&crm_user_postalcode={php} echo $current_user->address_postalcode;{/php}';
	$autoProvisionParam .= '&crm_user_country={php} echo $current_user->address_country;{/php}';
	$autoProvisionParam .= '&crm_server_url={php} echo $sugar_config[\'site_url\']{/php}';
	$autoProvisionParam .= '&crm_org_name={php}
							 if( strstr($sugar_config[\'host_name\'], \'sugarondemand\') ) 
							 {
								if(phpversion() >= 5) 
								 echo substr(parse_url($sugar_config[\'site_url\'], PHP_URL_PATH), 1);
								else{
									  $path = parse_url($sugar_config[\'site_url\']);
									  echo substr( $path[\'path\'], 1); 
									}
							}
							else
							 echo $sugar_config[\'host_name\'];
							{/php}';	
	$autoProvisionParam .= '&crm_host_name={php} echo $sugar_config[\'host_name\'];{/php}';
	$autoProvisionParam .= '&crm_user_id={php} 
								if ($current_user->id =="1")
								 echo $current_user->id.$sugar_config[\'unique_key\']; 
								else
								 echo $current_user->id;
							 {/php}';
	// NOW here comes the cool part.
	// We take the sugar user_name and user_hash to create a API session to be used by the Sync data feature.
	// Its stored in the php SESSION as we dont want to create new sessions for each mashup request.
    $autoProvisionParam .= '&crm_session_id={php} 
                if (is_null($_SESSION[\'IV_soap_session_id\']) || empty($_SESSION[\'IV_soap_session_id\']))
                {
	                $config[\'sugar_server\'] = $sugar_config[\'site_url\'] . \'/soap.php?wsdl\';
				    $config[\'login\'] = array(
						user_name => $current_user->user_name,
						password => $current_user->user_hash
						);
		                require_once(\'include/nusoap/nusoap.php\');
			            $sugarClient = new nusoapclient($config[\'sugar_server\'],TRUE);
						$err = $sugarClient->getError();
						if ($err) echo $err;
						$sugarClientProxy = $sugarClient->getProxy();
						if (!$sugarClientProxy) echo $err;
			            $result = $sugarClientProxy->login($config[\'login\'], \'insideview\');
	                    $_SESSION[\'IV_soap_session_id\'] = $result[\'id\']; 
                 }
	                 echo $_SESSION[\'IV_soap_session_id\'];
      		  {/php}';							 
	// END gettting autoProvision parameters

	/************************************************************************************************/
	echo "<br> ************<strong> Updating  the Accounts module with SalesView mashup </strong>************** <br>";
	// Start adding the iframes 
	// Accounts module first

	$account_field_name = 'insideview_account_c';

	$account_request_arr = array(
		'action' => 'SaveField',
		'is_update' => 'true',
		'module' => 'ModuleBuilder',
		'view_module' => 'Accounts',
		'view_package' => 'studio',

		'type' => 'html',
		'audited' => 0,
		'duplicate_merge' => 0,
		'ext4' => '',
		'help' => '',
		'label' => 'LBL_INSIDEVIEW',
		'label_value' => 'SalesView',
		'name' => $account_field_name,
		'reportable' => 0,
		'required' => 0,
	);

	// $account_request_arr should now contain all the necessary information to create a custom field
	// merge $request_arr with $_POST/$_REQUEST, where the action_saveField() method expects them
	$_REQUEST = array_merge($_REQUEST, $account_request_arr);
	$_POST = array_merge($_POST, $account_request_arr);

	$accountMBC = new ModuleBuilderController();
	$accountMBC->setup();
	$accountMBC->action_SaveField();

	// add the field to the Accounts DetailView layout
	$layout_properties = array(
		'name' => $account_field_name,
		'label' => 'LBL_INSIDEVIEW',
	);

	// Here we build the URL for the Account Mashup.
	$accountSearchParam = ''; 
	$accountSearchParam .= 'crm_account_name={$fields.name.value}';
	$accountSearchParam .= '&crm_account_ticker={$fields.ticker_symbol.value}';
	$accountSearchParam .= '&crm_account_id={$fields.id.value}';
	$accountSearchParam .= '&crm_context=account';
	$accountSearchParam .= '&crm_deploy_id=3';
	$accountSearchParam .= 	$autoProvisionParam;
	
	$layout_properties['customCode'] ='<iframe src=\'https://my.insideview.com/iv/crm/analyseAccount.do?'.$accountSearchParam.'\' width=\'100%\' height=\'200px\' marginwidth=\'0\' marginheight=\'0\' scrolling=\'no\' frameborder=\'0\'></iframe>'; 

	//The label that appears in the DetailView	for the Iframe
	$layout_properties['customLabel'] = 'SalesView';

	// adding the field to the DetailView
	$parser = ParserFactory::getParser('layoutview', FALSE);
	$parser->init('Accounts', 'DetailView', FALSE);

	$parser->_addField($layout_properties);
	$parser->writeWorkingFile();
	$parser->handleSave();

	//DONE adding the html field
	//Now - add the iframe to the detailView 
	include('custom/modules/Accounts/metadata/detailviewdefs.php');

	// access the first panel in the DetailView viewdefs
	foreach ($viewdefs['Accounts']['DetailView']['panels'] as $panel_k => $panel) {
		foreach ($panel as $row_k => $row) {
			foreach ($row as $field_k => $field) {

				// we've found the field we just added
				if ($field['name'] == $account_field_name) {

					// is the field already on a blank row, or is it sharing the row with another field?
					// either merge the field into the next row, or destroy the filler column on the current row
					// this will allow the field to span across the entire DetailView layout
					if ($field_k == 0) {
						unset($viewdefs['Accounts']['DetailView']['panels'][$panel_k][$row_k][1]);
					}
					else {
						$viewdefs['Accounts']['DetailView']['panels'][$panel_k][$row_k + 1][0] = $viewdefs['Accounts']['DetailView']['panels'][$panel_k][$row_k][1];
						$viewdefs['Accounts']['DetailView']['panels'][$panel_k][$row_k][1] = NULL;
					}

					$str_to_write = '<?php $viewdefs = ';
					$str_to_write .= var_export($viewdefs, TRUE);
					$str_to_write .= ';?>';

					$fp = fopen('custom/modules/Accounts/metadata/detailviewdefs.php', 'wb');
					fwrite($fp, $str_to_write);
					fclose($fp);
				}
			}
		}
	}
	echo "<br>DONE<br><br>";
	//  END THE ACCOUNT MASHUP
	/************************************************************************************************/
	echo "<br> ************<strong> Updating  the Leads module with SalesView mashup </strong>************** <br>";	
	//LEAD MASHUP starts here
	$lead_field_name = 'insideview_lead_c';

	$lead_request_arr = array(
		'action' => 'SaveField',
		'is_update' => 'true',
		'module' => 'ModuleBuilder',
		'view_module' => 'Leads',
		'view_package' => 'studio',

		'type' => 'html',
		'audited' => 0,
		'duplicate_merge' => 0,
		'ext4' => '',
		'help' => '',
		'label' => 'LBL_INSIDEVIEW',
		'label_value' => 'SalesView',
		'name' => $lead_field_name,
		'reportable' => 0,
		'required' => 0,
	);

	// $lead_request_arr should now contain all the necessary information to create a custom field
	// merge $lead_request_arr with $_POST/$_REQUEST, where the action_saveField() method expects them
	$_REQUEST = array_merge($_REQUEST, $lead_request_arr);
	$_POST = array_merge($_POST, $lead_request_arr);

	$leadMBC = new ModuleBuilderController();
	$leadMBC->setup();
	$leadMBC->action_SaveField();

	// add the field to the Leads DetailView layout
	$layout_properties = array(
		'name' => $lead_field_name,
		'label' => 'LBL_INSIDEVIEW',
	);

	$leadSearchParam = ''; 
	$leadSearchParam .= 'crm_account_name={$fields.account_name.value}';
	//$leadSearchParam .= '&crm_account_ticker={$fields.ticker_symbol.value}'; //Leads do not have the Ticker field
	$leadSearchParam .= '&crm_account_id={$fields.id.value}';
	$leadSearchParam .= '&crm_context=lead';
	$leadSearchParam .= '&crm_deploy_id=3';
	$leadSearchParam .= $autoProvisionParam;

	$layout_properties['customCode'] ='<iframe src=\'https://my.insideview.com/iv/crm/analyseAccount.do?'.$leadSearchParam.'\' width=\'100%\' height=\'200px\' marginwidth=\'0\' marginheight=\'0\' scrolling=\'no\' frameborder=\'0\'></iframe>'; 
	
	//The label that appears in the DetailView	for the Iframe
	$layout_properties['customLabel'] = 'SalesView';

	// adding the field to the DetailView
	$leadViewParser = ParserFactory::getParser('layoutview', FALSE);
	$leadViewParser->init('Leads', 'DetailView', FALSE);

	$leadViewParser->_addField($layout_properties);
	$leadViewParser->writeWorkingFile();
	$leadViewParser->handleSave();
	//DONE adding the html field
	
	//Now - Add the iframe to the Lead DetailView
	include('custom/modules/Leads/metadata/detailviewdefs.php');

	// access the first panel in the DetailView viewdefs
	foreach ($viewdefs['Leads']['DetailView']['panels'] as $panel_k => $panel) {
		foreach ($panel as $row_k => $row) {
			foreach ($row as $field_k => $field) {

				// we've found the field we just added
				if ($field['name'] == $lead_field_name) {

					// is the field already on a blank row, or is it sharing the row with another field?
					// either merge the field into the next row, or destroy the filler column on the current row
					// this will allow the field to span across the entire DetailView layout
					if ($field_k == 0) {
						unset($viewdefs['Leads']['DetailView']['panels'][$panel_k][$row_k][1]);
					}
					else {
						$viewdefs['Leads']['DetailView']['panels'][$panel_k][$row_k + 1][0] = $viewdefs['Leads']['DetailView']['panels'][$panel_k][$row_k][1];
						$viewdefs['Leads']['DetailView']['panels'][$panel_k][$row_k][1] = NULL;
					}

					$str_to_write = '<?php $viewdefs = ';
					$str_to_write .= var_export($viewdefs, TRUE);
					$str_to_write .= ';?>';

					$fp = fopen('custom/modules/Leads/metadata/detailviewdefs.php', 'wb');
					fwrite($fp, $str_to_write);
					fclose($fp);
				}
			}
		}
	}
	echo "<br>DONE<br><br>";
	// END Lead Mashup
	/************************************************************************************************/
	//Oppurtunities mashup starts here
	echo "<br> ************<strong> Updating  the Opportunities module with SalesView mashup </strong>************** <br>";
	$Opportunities_field_name = 'insideview_opportunities_c';

	$Opportunities_request_arr = array(
		'action' => 'SaveField',
		'is_update' => 'true',
		'module' => 'ModuleBuilder',
		'view_module' => 'Opportunities',
		'view_package' => 'studio',

		'type' => 'html',
		'audited' => 0,
		'duplicate_merge' => 0,
		'ext4' => '',
		'help' => '',
		'label' => 'LBL_INSIDEVIEW',
		'label_value' => 'SalesView',
		'name' => $Opportunities_field_name,
		'reportable' => 0,
		'required' => 0,
	);

	// $Opportunities_request_arr should now contain all the necessary information to create a custom field
	// merge $request_arr with $_POST/$_REQUEST, where the action_saveField() method expects them
	$_REQUEST = array_merge($_REQUEST, $Opportunities_request_arr);
	$_POST = array_merge($_POST, $Opportunities_request_arr);

	$OpportunitiesMBC = new ModuleBuilderController();
	$OpportunitiesMBC->setup();
	$OpportunitiesMBC->action_SaveField();
	//DONE adding the html field


	//Now - add the field to the Opportunities DetailView layout
	$layout_properties = array(
		'name' => $Opportunities_field_name,
		'label' => 'LBL_INSIDEVIEW',
	);


	// Here we build the URL for the Opportunities Mashup.

	$OpportunitiesSearchParam = ''; 
	$OpportunitiesSearchParam .= 'crm_account_name={$fields.account_name.value}';
	//$OpportunitiesSearchParam .= '&crm_account_ticker={$fields.ticker_symbol.value}'; //Opportunities dont have Account Ticker available.
	$OpportunitiesSearchParam .= '&crm_account_id={$fields.account_id.value}';
	$OpportunitiesSearchParam .= '&crm_context=opportunities';
	$OpportunitiesSearchParam .= '&crm_deploy_id=3';
	$OpportunitiesSearchParam .= $autoProvisionParam;
	$layout_properties['customCode'] ='<iframe src=\'https://my.insideview.com/iv/crm/analyseAccount.do?'.$OpportunitiesSearchParam.'\' width=\'100%\' height=\'200px\' marginwidth=\'0\' marginheight=\'0\' scrolling=\'no\' frameborder=\'0\'></iframe>'; 
	
	// this should be left as blank (so no label appears on the DetailView layout)
	$layout_properties['customLabel'] = 'SalesView';

	// add the field to the DetailView
	$OpportunitiesParser = ParserFactory::getParser('layoutview', FALSE);
	$OpportunitiesParser->init('Opportunities', 'DetailView', FALSE);

	$OpportunitiesParser->_addField($layout_properties);
	$OpportunitiesParser->writeWorkingFile();
	$OpportunitiesParser->handleSave();

	include('custom/modules/Opportunities/metadata/detailviewdefs.php');

	// access the first panel in the DetailView viewdefs
	foreach ($viewdefs['Opportunities']['DetailView']['panels'] as $panel_k => $panel) {
		foreach ($panel as $row_k => $row) {
			foreach ($row as $field_k => $field) {

				// we've found the field we just added
				if ($field['name'] == $Opportunities_field_name) {

					// is the field already on a blank row, or is it sharing the row with another field?
					// either merge the field into the next row, or destroy the filler column on the current row
					// this will allow the field to span across the entire DetailView layout
					if ($field_k == 0) {
						unset($viewdefs['Opportunities']['DetailView']['panels'][$panel_k][$row_k][1]);
					}
					else {
						$viewdefs['Opportunities']['DetailView']['panels'][$panel_k][$row_k + 1][0] = $viewdefs['Opportunities']['DetailView']['panels'][$panel_k][$row_k][1];
						$viewdefs['Opportunities']['DetailView']['panels'][$panel_k][$row_k][1] = NULL;
					}

					$str_to_write = '<?php $viewdefs = ';
					$str_to_write .= var_export($viewdefs, TRUE);
					$str_to_write .= ';?>';

					$fp = fopen('custom/modules/Opportunities/metadata/detailviewdefs.php', 'wb');
					fwrite($fp, $str_to_write);
					fclose($fp);
				}
			}
		}
	}
	echo "<br>DONE<br><br>";
	echo "<br> ***********************************************************************************************************<br>";
	echo "<br><strong><font color='green'>Congratulations, SalesView has been successfully Installed. Please check your Account/Lead/Opportunity modules.</font> </strong><br>";
	echo "<br><h4><strong><font color='red'> Inorder for SalesView to work properly, please update your email address in SugarCRM User Details by clicking on <u> My Account </u> on top of the page </font></strong></h4><br>";
	echo "<br> ***********************************************************************************************************<br>";

	/*********************************THE END********************************************************/	
}

?>
