<?php
$manifest = array(
	'acceptable_sugar_versions' => array('*'),
	'name' => 'SalesView for SugarCRM 2.0.1b',
	'description' => 'Installs a SalesView mashup into the Accounts, Leads & Opportunities detail pages.',
	'author' => 'InsideView Technologies',
	'published_date' => '2008/05/08',
	'version' => '2.0.1b',
	'type' => 'module',
	'icon' => '',
	'is_uninstallable' => 'true',
);

$installdefs = array();
?>
