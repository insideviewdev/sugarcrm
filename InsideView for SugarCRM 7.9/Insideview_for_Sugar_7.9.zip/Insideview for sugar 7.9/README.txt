﻿'InsideView for Sales' ™ dashlet for SugarCRM 7

InsideView benefits:

What if you could get a warm introduction to each of your prospects and could prepare for meetings in just minutes? From the InsideView dashlet in Sugar 7, you do much more:

* Get company and contact information from editorial sources like Reuters and NetProspex, and social media from LinkedIn, Twitter, Facebook, and blogs.

* See full contact details including email addresses and direct phone.

* Be alerted via Smart Agent™ technology to key sales triggers like management changes or contract awards.

* Turn cold calls into warm introductions through a private connections network that reveals all the connections between you, your work colleagues and your prospects, without exposing your corporate relationship assets to the outside world.

* Sync to Sugar with one click to update records and prospect lists.

* Create targeted lists and export them to Sugar, to reach the right prospects at the right time.

* Have relevant business information at your fingertips before making the first call.

* Gain more leads, convert more prospects, and win more business.
