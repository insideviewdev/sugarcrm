<?php
if(!defined('sugarEntry'))define('sugarEntry', true);

$viewdefs['Home']['base']['view']['insideview'] = array(
    'dashlets' => array(
        array(
            'name' => '\'InsideView for Sales\'',
			'label' => '\'InsideView for Sales\'',
			'title' => '\'InsideView for Sales\'',
            'description' => '\'InsideView for Sales\' for SugarCRM 7',
            'config' => array(
                'baseurl' => 'https://my.insideview.com/'
            ),
            'preview' => array(
                'url' => 'https://my.insideview.com/',
            ),
            'filter' => array(
                'module' => array('Accounts','Contacts','Opportunities','Leads'),
                'view' => 'record'
            ),
        ),
    ),
    'view_panel' => array(
        array(
            'type' => 'iframe',
            'name' => 'url',
            'label' => 'URL',
        ),
    ),
);
