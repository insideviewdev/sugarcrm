({
	plugins : [ 'Dashlet' ],
	processParam : function(param) {
		if (!param || typeof param == 'undefined') {
			param = '';
		}
		return encodeURIComponent(param);
	},
	getUserParams : function(thisRef, restParams) {

		var queryString = "";
		var crm_org_id = restParams.crm_org_id;
		var crm_org_name = restParams.crm_org_name;
		var crm_user_email = restParams.crm_user_email;
		var crm_server_url = restParams.crm_server_url;
		var crm_host_name = restParams.crm_host_name;
		var crm_deploy_id = "3";
		var crm_version = "v99";
		var crm_size = "400";
		var crm_user_firstname = restParams.crm_user_firstname;
		var crm_user_lastname = restParams.crm_user_lastname;
		var crm_user_id = restParams.crm_user_id;
		var crm_user_name = restParams.crm_user_name;
		var sugar_version = restParams.sugar_version;
		var crm_session_id = "";

		queryString = "crm_org_id=" + thisRef.processParam(crm_org_id) + "&"
				+ "crm_org_name=" + thisRef.processParam(crm_org_name) + "&"
				+ "crm_user_id=" + thisRef.processParam(crm_user_id) + "&"
				+ "crm_user_name=" + thisRef.processParam(crm_user_name) + "&"
				+ "crm_user_firstname="
				+ thisRef.processParam(crm_user_firstname) + "&"
				+ "crm_user_lastname="
				+ thisRef.processParam(crm_user_lastname) + "&"
				+ "crm_user_email=" + thisRef.processParam(crm_user_email)
				+ "&" + "crm_deploy_id=" + thisRef.processParam(crm_deploy_id)
				+ "&" + "crm_server_url="
				+ thisRef.processParam(crm_server_url) + "&" + "crm_version="
				+ thisRef.processParam(crm_version) + "&" + "crm_session_id="
				+ thisRef.processParam(crm_session_id) + "&" + "crm_size="
				+ thisRef.processParam(crm_size) + "&" + "crm_host_name="
				+ thisRef.processParam(crm_host_name) + "&" + "crm_token="
				+ thisRef.oauth + "&" 
				+ "user_type=" + thisRef.processParam(app.user.get('type')) + "&"
				+ "appVersion=" + thisRef.processParam(sugar_version) + "&"
				+ "solutionVersion=1.0" + "&";
		return queryString;
	},

	getModuleParams : function(thisRef, userParamString) {
		var queryString = "";
		var crm_context = thisRef.model.get("_module");

		switch (crm_context) {
		case "Accounts":
			var crm_context = "account";
			var crm_account_name = thisRef.model.get('name');
			var crm_account_id = thisRef.model.get('id');
			var crm_account_ticker = thisRef.model.get('ticker_symbol');
			var crm_account_website = thisRef.model.get('website');
			var crm_account_city = thisRef.model.get('billing_address_city') ? thisRef.model
					.get('billing_address_city')
					: thisRef.model.get('shippping_address_city');
			var crm_account_state = thisRef.model.get('billing_address_state') ? thisRef.model
					.get('billing_address_state')
					: thisRef.model.get('shippping_address_state');
			var crm_account_postalcode = thisRef.model
					.get('billing_address_postalcode') ? thisRef.model
					.get('billing_address_postalcode') : thisRef.model
					.get('shippping_address_postalcode');
			var crm_account_country = thisRef.model
					.get('billing_address_country') ? thisRef.model
					.get('billing_address_country') : thisRef.model
					.get('shippping_address_country');

			queryString = "iv/crm/basic/company/analyze.iv?" + userParamString
					+ "crm_context=" + thisRef.processParam(crm_context) + "&"
					+ "crm_account_id=" + thisRef.processParam(crm_account_id)
					+ "&" + "crm_account_name="
					+ thisRef.processParam(crm_account_name) + "&"
					+ "crm_account_ticker="
					+ thisRef.processParam(crm_account_ticker) + "&"
					+ "crm_account_website="
					+ thisRef.processParam(crm_account_website) + "&"
					+ "crm_account_city="
					+ thisRef.processParam(crm_account_city) + "&"
					+ "crm_account_state="
					+ thisRef.processParam(crm_account_state) + "&"
					+ "crm_account_postalcode="
					+ thisRef.processParam(crm_account_postalcode) + "&"
					+ "crm_account_country="
					+ thisRef.processParam(crm_account_country);

			break;
		case "Contacts":
			var crm_context = "contact";
			var crm_object_id = thisRef.model.get('id');
			var crm_account_id = thisRef.model.get('account_id');
			var crm_account_name = thisRef.model.get('account_name');
			var crm_fn = thisRef.model.get('first_name');
			var crm_ln = thisRef.model.get('last_name');
			var crm_email = thisRef.model.get('email')
					&& thisRef.model.get('email')[0] ? thisRef.model
					.get('email')[0].email_address : "";
			var crm_title = thisRef.model.get('title');
			var crm_account_ticker = "";
			var crm_account_website = "";
			var crm_account_city = thisRef.model.get('primary_address_city') ? thisRef.model
					.get('primary_address_city')
					: thisRef.model.get('alt_address_city');
			var crm_account_state = thisRef.model.get('primary_address_state') ? thisRef.model
					.get('primary_address_state')
					: thisRef.model.get('alt_address_state');
			var crm_account_postalcode = thisRef.model
					.get('primary_address_postalcode') ? thisRef.model
					.get('primary_address_postalcode') : thisRef.model
					.get('alt_address_postalcode');
			var crm_account_country = thisRef.model
					.get('primary_address_country') ? thisRef.model
					.get('primary_address_country') : thisRef.model
					.get('alt_address_country');

			queryString = "iv/crm/basic/executive/analyze.iv?"
					+ userParamString + "crm_context="
					+ thisRef.processParam(crm_context) + "&"
					+ "crm_object_id=" + thisRef.processParam(crm_object_id)
					+ "&" + "crm_fn=" + thisRef.processParam(crm_fn) + "&"
					+ "crm_ln=" + thisRef.processParam(crm_ln) + "&"
					+ "crm_title=" + thisRef.processParam(crm_title) + "&"
					+ "crm_email=" + thisRef.processParam(crm_email) + "&"
					+ "crm_account_id=" + thisRef.processParam(crm_account_id)
					+ "&" + "crm_account_name="
					+ thisRef.processParam(crm_account_name) + "&"
					+ "crm_account_ticker="
					+ thisRef.processParam(crm_account_ticker) + "&"
					+ "crm_account_website="
					+ thisRef.processParam(crm_account_website) + "&"
					+ "crm_account_city="
					+ thisRef.processParam(crm_account_city) + "&"
					+ "crm_account_state="
					+ thisRef.processParam(crm_account_state) + "&"
					+ "crm_account_postalcode="
					+ thisRef.processParam(crm_account_postalcode) + "&"
					+ "crm_account_country="
					+ thisRef.processParam(crm_account_country);
			break;
		case "Opportunities":
			var crm_context = "opportunity";
			var crm_opportunity_id = thisRef.model.get('id');
			var crm_account_name = thisRef.model.get('account_name');
			var crm_account_id = thisRef.model.get('account_id');
			var crm_account_ticker = "";
			var crm_account_website = "";
			var crm_account_city = "";
			var crm_account_state = "";
			var crm_account_postalcode = "";
			var crm_account_country = "";

			queryString = "iv/crm/basic/company/analyze.iv?" + userParamString
					+ "crm_context=" + thisRef.processParam(crm_context) + "&"
					+ "crm_account_id=" + thisRef.processParam(crm_account_id)
					+ "&" + "crm_opportunity_id="
					+ thisRef.processParam(crm_opportunity_id) + "&"
					+ "crm_account_name="
					+ thisRef.processParam(crm_account_name) + "&"
					+ "crm_account_website="
					+ thisRef.processParam(crm_account_website) + "&"
					+ "crm_account_ticker="
					+ thisRef.processParam(crm_account_ticker) + "&"
					+ "crm_account_city="
					+ thisRef.processParam(crm_account_city) + "&"
					+ "crm_account_state="
					+ thisRef.processParam(crm_account_state) + "&"
					+ "crm_account_postalcode="
					+ thisRef.processParam(crm_account_postalcode) + "&"
					+ "crm_account_country="
					+ thisRef.processParam(crm_account_country);
			break;
		case "Leads":
			var crm_context = "lead";
			var crm_lead_id = thisRef.model.get('id');
			var crm_lead_firstname = thisRef.model.get('first_name');
			var crm_lead_lastname = thisRef.model.get('last_name');
			var crm_lead_title = thisRef.model.get('title');
			var crm_lead_email = thisRef.model.get('email')
					&& thisRef.model.get('email')[0] ? thisRef.model
					.get('email')[0].email_address : "";
			var crm_account_id = thisRef.model.get('id');
			var crm_account_name = thisRef.model.get('account_name');
			var crm_account_website = thisRef.model.get('website');
			var crm_account_ticker = "";
			var crm_account_city = thisRef.model.get('primary_address_city') ? thisRef.model
					.get('primary_address_city')
					: thisRef.model.get('alt_address_city');
			var crm_account_state = thisRef.model.get('primary_address_state') ? thisRef.model
					.get('primary_address_state')
					: thisRef.model.get('alt_address_state');
			var crm_account_postalcode = thisRef.model
					.get('primary_address_postalcode') ? thisRef.model
					.get('primary_address_postalcode') : thisRef.model
					.get('alt_address_postalcode');
			var crm_account_country = thisRef.model
					.get('primary_address_country') ? thisRef.model
					.get('primary_address_country') : thisRef.model
					.get('alt_address_country');

			queryString = "iv/crm/basic/company/analyze.iv?" + userParamString
					+ "crm_context=" + thisRef.processParam(crm_context) + "&"
					+ "crm_lead_id=" + thisRef.processParam(crm_lead_id) + "&"
					+ "crm_lead_firstname="
					+ thisRef.processParam(crm_lead_firstname) + "&"
					+ "crm_lead_lastname="
					+ thisRef.processParam(crm_lead_lastname) + "&"
					+ "crm_lead_title=" + thisRef.processParam(crm_lead_title)
					+ "&" + "crm_lead_email="
					+ thisRef.processParam(crm_lead_email) + "&"
					+ "crm_account_id=" + thisRef.processParam(crm_account_id)
					+ "&" + "crm_account_name="
					+ thisRef.processParam(crm_account_name) + "&"
					+ "crm_account_website="
					+ thisRef.processParam(crm_account_website) + "&"
					+ "crm_account_ticker="
					+ thisRef.processParam(crm_account_ticker) + "&"
					+ "crm_account_city="
					+ thisRef.processParam(crm_account_city) + "&"
					+ "crm_account_state="
					+ thisRef.processParam(crm_account_state) + "&"
					+ "crm_account_postalcode="
					+ thisRef.processParam(crm_account_postalcode) + "&"
					+ "crm_account_country="
					+ thisRef.processParam(crm_account_country);
			break;
		}

		return queryString;

	},
	getUrl : function(params, thisRef) {
		var userParamString = thisRef.getUserParams(thisRef, arguments[0]);
		var url = thisRef.getModuleParams(thisRef, userParamString);
		return url;
	},

	_render : function() {
		if (!this.meta.config) {

			this.dashletConfig.view_panel[0].height = '340px';
			this.dashletConfig.view_panel[0].width = '99%';
		}
		var baseUrl = this.settings.get("baseurl");

		var endpointURL = app.config.siteUrl + app.config.serverUrl
				+ "/insideview/orgData";
		var thisRef = this;

		// console.debug(app.api.getOAuthToken());
		thisRef.oauth = app.api.getOAuthToken();

		app.api.call('GET', endpointURL, '', {
			success : function() {
				var url = thisRef.getUrl(arguments[0], thisRef);
				thisRef.settings.set("url", baseUrl + url);
				app.view.View.prototype._render.call(thisRef);
			},
			error : function() {
				// console.log('in error');
				// console.log(arguments);
			}
		}, '');
	},

	initDashlet : function(view) {
		this.viewName = view;
		this.model.on('change:name', this.render, this);
		this.model.on('change:full_name', this.render, this);
	}
})
