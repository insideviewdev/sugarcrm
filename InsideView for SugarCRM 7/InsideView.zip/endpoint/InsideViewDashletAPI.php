<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class InsideViewDashletAPI extends SugarApi {
    public function registerApiRest() {
        return array(
            'MyGetEndpoint' => array(
                'reqType' => 'GET', //request type
                'path' => array('insideview', 'orgData'), //endpoint path
                'pathVars' => array('',''), //endpoint variables
                'method' => 'getData', //method to call
                'shortHelp' => 'API to get data for the InsideView dashlet', //short help string to be displayed in the help documentation
                'longHelp' => 'API to get data for the InsideView dashlet', //long help to be displayed in the help documentation
            ),
        );
    }

    public function getData($api, $args) {
        global $current_user;
		global $sugar_config;
		global $system_config;
		
		$user_id = $current_user->id;
		
		//if id is 1 use org id
		if($user_id == '1') {
			$user_id = $sugar_config['unique_key'];
		}
				
		$crm_org_name = $system_config->settings['system_name'];
		if(strcmp($crm_org_name,'SugarCRM') == 0) {
			$crm_org_name = $sugar_config['host_name'];
		}
		if(strpos($crm_org_name,".trial.sugarcrm.com") !== false) {
			$arr = explode(".trial.sugarcrm.com", $crm_org_name);
			$crm_org_name = trim($arr[0]);
		} else if(strpos($crm_org_name,".sugarondemand.com") !== false) {
			$arr = explode(".sugarondemand.com", $crm_org_name);
			$crm_org_name = trim($arr[0]);
		}
		
		$crm_server_url = $sugar_config['site_url'];
		if(substr($crm_server_url, -strlen('/')) === '/') {
			$crm_server_url = substr($crm_server_url, 0, -1);
			$crm_server_url = trim($crm_server_url);
		}
		
		$data = array('crm_org_id' => $sugar_config['unique_key'],
						'crm_org_name' => $crm_org_name,
						'crm_user_id' => $user_id,
						'crm_user_email' => $current_user->email1,
						'crm_user_firstname' => $current_user->first_name,
						'crm_user_lastname' => $current_user->last_name,
						'crm_user_name' => $current_user->user_name,
						'crm_server_url' => $crm_server_url,
						'crm_host_name' => $sugar_config['host_name'],
						'sugar_version' => $sugar_config['sugar_version']);
		
		return $data;
    }
}
?>