
If you upgrading from previous versions or re-installing the same version
or if you are unsure of how the previous installation/un-installation went,
please make sure that the previous version is cleanly uninstalled.
Here are the steps to cleanly uninstall the previous installation.

1.  Uninstall and remove the previous versions of 'SalesView for SugarCRM'
2.  Go to Admin > Studio > Accounts > Layouts > DetailView: if any SALESVIEW field is present, remove from the layout.
3.  Save and deploy the DetailView layout.
4.  Repeat the above steps for Leads, Opportunities, Contacts.
5.  Follow the steps mentioned in the attached document to reinstall the application again.

