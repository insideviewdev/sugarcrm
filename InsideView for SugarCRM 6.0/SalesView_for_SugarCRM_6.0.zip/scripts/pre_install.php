<?php
function pre_install()
{
	global $current_user;
	

	require_once('include/utils.php');
	require_once('include/utils/file_utils.php');
	require_once('config.php');
	require_once('include/database/PearDatabase.php');

	require_once('include/MVC/Controller/SugarController.php');
	require_once('modules/ModuleBuilder/controller.php');
	require_once('modules/ModuleBuilder/parsers/ParserFactory.php');

	//echo"<br><h4>You can <strong>safely ignore</strong> if there are <strong>any errors</strong> during the installation</h4><br>";

	// We will try to get the parameters required for autoProvisining and later append it to the Iframe URL.
	$autoProvisionParam = '';
	$autoProvisionParam .= '&crm_org_id={php} global $sugar_config; echo $sugar_config[\'unique_key\'];{/php}';
	//$autoProvisionParam .= '&crm_session_id={php} $sessionId= session_id(); echo $sessionId; {/php}';
	$autoProvisionParam .= '&crm_user_firstname={php}global $current_user; echo $current_user->first_name; {/php}';
	$autoProvisionParam .= '&crm_user_lastname={php} echo $current_user->last_name;{/php}';
	$autoProvisionParam .= '&crm_user_title={php} echo $current_user->title;{/php}';
	$autoProvisionParam .= '&crm_user_email={php} echo $current_user->email1;{/php}';
	$autoProvisionParam .= '&crm_user_phone={php} echo $current_user->phone_work;{/php}';
	$autoProvisionParam .= '&crm_user_street={php} echo $current_user->address_street;{/php}';
	$autoProvisionParam .= '&crm_user_city={php} echo $current_user->address_city;{/php}';
	$autoProvisionParam .= '&crm_user_state={php} echo $current_user->address_state;{/php}';
	$autoProvisionParam .= '&crm_user_postalcode={php} echo $current_user->address_postalcode;{/php}';
	$autoProvisionParam .= '&crm_user_country={php} echo $current_user->address_country;{/php}';
	$autoProvisionParam .= '&crm_server_url={php} echo $sugar_config[\'site_url\']{/php}';
	$autoProvisionParam .= '&crm_org_name={php}
							 if( strstr($sugar_config[\'host_name\'], \'sugarondemand\') ) 
							 {
								if(phpversion() >= 5) 
								 echo substr(parse_url($sugar_config[\'site_url\'], PHP_URL_PATH), 1);
								else{
									  $path = parse_url($sugar_config[\'site_url\']);
									  echo substr( $path[\'path\'], 1); 
									}
							}
							else
							 echo $sugar_config[\'host_name\'];
							{/php}';	
	$autoProvisionParam .= '&crm_host_name={php} echo $sugar_config[\'host_name\'];{/php}';
	$autoProvisionParam .= '&crm_user_id={php} 
								if ($current_user->id =="1")
								 echo $current_user->id.$sugar_config[\'unique_key\']; 
								else
								 echo $current_user->id;
							 {/php}';
	// NOW here comes the cool part.
	// We take the sugar user_name and user_hash to create a API session to be used by the Sync data feature.
	// Its stored in the php SESSION as we dont want to create new sessions for each mashup request.
    $autoProvisionParam .= '&crm_session_id=';							 
    $autoProvisionParam .= '&crm_version=v47';							 
	// END gettting autoProvision parameters

	/************************************************************************************************/
	echo "<br> ************<strong> Adding SalesView to the Accounts module </strong>************** <br>";
	// Start adding the iframes 
	// Accounts module first

	$account_field_name = 'insideview_account_c';
	// add the field to the Accounts DetailView layout
	$layout_properties = array(
		'name' => $account_field_name,
		'label' => 'LBL_SALESVIEW',
	);

	// Here we build the URL for the Account Mashup.
	$accountSearchParam = ''; 
	$accountSearchParam .= 'crm_account_name={$fields.name.value}';
	$accountSearchParam .= '&crm_account_ticker={$fields.ticker_symbol.value}';
	$accountSearchParam .= '&crm_account_id={$fields.id.value}';
	$accountSearchParam .= '&crm_context=account';
	$accountSearchParam .= '&crm_deploy_id=3';
	$accountSearchParam .= '&crm_size=400';
	$accountSearchParam .= 	$autoProvisionParam;
	
	$layout_properties['customCode'] ='<iframe src=\'https://my.insideview.com/iv/crm/analyseAccount.do?'.$accountSearchParam.'\' width=\'100%\' height=\'400px\' marginwidth=\'0\' marginheight=\'0\' scrolling=\'no\' frameborder=\'0\'></iframe>'; 

	//The label that appears in the DetailView	for the Iframe
	$layout_properties['customLabel'] = 'SalesView';

	// adding the field to the DetailView
	$parser = ParserFactory::getParser('detailview', 'Accounts');
    $panels = array_keys ( $parser->_viewdefs [ 'panels' ] ) ;
    $parser->_viewdefs['panels'][$panels[0]][] = array($layout_properties);
    
    $parser->handleSave(false);

	echo "<br>DONE<br><br>";
	//  END THE ACCOUNT MASHUP
	/************************************************************************************************/
	echo "<br> ************<strong> Adding SalesView to the Leads module </strong>************** <br>";	
	//LEAD MASHUP starts here
	$lead_field_name = 'insideview_lead_c';
	// add the field to the Leads DetailView layout
	$layout_properties = array(
		'name' => $lead_field_name,
		'label' => 'LBL_SALESVIEW',
	);

	$leadSearchParam = ''; 
	$leadSearchParam .= 'crm_account_name={$fields.account_name.value}';
	//$leadSearchParam .= '&crm_account_ticker={$fields.ticker_symbol.value}'; //Leads do not have the Ticker field
	$leadSearchParam .= '&crm_account_id={$fields.id.value}';
	$leadSearchParam .= '&crm_context=lead';
	$leadSearchParam .= '&crm_deploy_id=3';
	$leadSearchParam .= '&crm_size=400';
	$leadSearchParam .= $autoProvisionParam;

	$layout_properties['customCode'] ='<iframe src=\'https://my.insideview.com/iv/crm/analyseAccount.do?'.$leadSearchParam.'\' width=\'100%\' height=\'400px\' marginwidth=\'0\' marginheight=\'0\' scrolling=\'no\' frameborder=\'0\'></iframe>'; 
	
	//The label that appears in the DetailView	for the Iframe
	$layout_properties['customLabel'] = 'SalesView';

	// adding the field to the DetailView
	$parser = ParserFactory::getParser('detailview', 'Leads');
    $panels = array_keys ( $parser->_viewdefs [ 'panels' ] ) ;
    $parser->_viewdefs['panels'][$panels[0]][] = array($layout_properties);
    
    $parser->handleSave(false);

	echo "<br>DONE<br><br>";
	// END Lead Mashup
	/************************************************************************************************/
	//Oppurtunities mashup starts here
	echo "<br> ************<strong> Adding SalesView to the Opportunities module </strong>************** <br>";
	$Opportunities_field_name = 'insideview_opportunities_c';

	//Now - add the field to the Opportunities DetailView layout
	$layout_properties = array(
		'name' => $Opportunities_field_name,
		'label' => 'LBL_SALESVIEW',
	);


	// Here we build the URL for the Opportunities Mashup.

	$OpportunitiesSearchParam = ''; 
	$OpportunitiesSearchParam .= 'crm_account_name={$fields.account_name.value}';
	//$OpportunitiesSearchParam .= '&crm_account_ticker={$fields.ticker_symbol.value}'; //Opportunities dont have Account Ticker available.
	$OpportunitiesSearchParam .= '&crm_account_id={$fields.account_id.value}';
	$OpportunitiesSearchParam .= '&crm_context=opportunities';
	$OpportunitiesSearchParam .= '&crm_deploy_id=3';
	$OpportunitiesSearchParam .= '&crm_size=400';
	$OpportunitiesSearchParam .= $autoProvisionParam;
	$layout_properties['customCode'] ='<iframe src=\'https://my.insideview.com/iv/crm/analyseAccount.do?'.$OpportunitiesSearchParam.'\' width=\'100%\' height=\'400px\' marginwidth=\'0\' marginheight=\'0\' scrolling=\'no\' frameborder=\'0\'></iframe>'; 
	
	// this should be left as blank (so no label appears on the DetailView layout)
	$layout_properties['customLabel'] = 'SalesView';

	// add the field to the DetailView
	$parser = ParserFactory::getParser('detailview', 'Opportunities');
    $panels = array_keys ( $parser->_viewdefs [ 'panels' ] ) ;
    $parser->_viewdefs['panels'][$panels[0]][] = array($layout_properties);
    
    $parser->handleSave(false);

	echo "<br>DONE<br><br>";
	echo "<br> ***********************************************************************************************************<br>";
	echo "<br><strong><font color='green'>Congratulations, SalesView has been successfully Installed. Please check your Account/Lead/Opportunity modules.</font> </strong><br>";
	echo "<br><h4><strong><font color='red'> In order for SalesView to work properly, please update your email address in SugarCRM User Details by clicking on <u> My Account </u> on top of the page </font></strong></h4><br>";
	echo "<br> ***********************************************************************************************************<br>";

	/*********************************THE END********************************************************/	
}

?>
