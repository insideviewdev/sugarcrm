<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class InsideViewTokenValidationAPI extends SugarApi {
    public function registerApiRest() {
        return array(
            'MyGetEndpoint' => array(
                'reqType' => 'GET', //request type
                'path' => array('insideview', 'validatetoken'), //endpoint path
                'pathVars' => array('',''), //endpoint variables
                'method' => 'getData', //method to call
                'shortHelp' => 'API to get data for the InsideView dashlet', //short help string to be displayed in the help documentation
                'longHelp' => 'API to get data for the InsideView dashlet', //long help to be displayed in the help documentation
            ),
        );
    }

    public function getData($api, $args) {
        global $current_user;
		global $sugar_config;
		global $system_config;

		$user_id = $current_user->id;

		//if id is 1 use org id
		if($user_id == '1') {
			$user_id = $sugar_config['unique_key'];
		}

		$crm_org_name = $system_config->settings['system_name'];
		if(strcmp($crm_org_name,'SugarCRM') == 0) {
			$crm_org_name = $sugar_config['host_name'];
		}
		if(strpos($crm_org_name,".trial.sugarcrm.com") !== false) {
			$arr = explode(".trial.sugarcrm.com", $crm_org_name);
			$crm_org_name = trim($arr[0]);
		} else if(strpos($crm_org_name,".sugarondemand.com") !== false) {
			$arr = explode(".sugarondemand.com", $crm_org_name);
			$crm_org_name = trim($arr[0]);
		}

		$token = $args['crm_token'];
		$oauthServer = SugarOAuth2Server::getOAuth2Server();
		$result = '';

		try {
    		$result = $oauthServer->verifyAccessToken($token);
		} catch ( OAuth2AuthenticateException $e ) {
			$GLOBALS['log']->debug($e);
            $result['user_id'] = '';
		}

		$data = array('crm_org_id' => $sugar_config['unique_key'],
						'crm_org_name' => $crm_org_name,
						'crm_user_id' => $result['user_id']);

		return $data;
    }
}
?>