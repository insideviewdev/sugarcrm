({
	plugins : [ 'Dashlet' ],
	processParam : function(param) {
		if (!param || typeof param == 'undefined') {
			param = '';
		}
		return encodeURIComponent(param);
	},
	getUserParams : function(thisRef, restParams) {
		var crm_org_id = restParams.crm_org_id;
		var crm_org_name = restParams.crm_org_name;
		var crm_user_email = restParams.crm_user_email;
		var crm_server_url = restParams.crm_server_url;
		var crm_host_name = restParams.crm_host_name;
		var crm_deploy_id = "3";
		var crm_version = "v99";
		var crm_size = "400";
		var crm_user_id = restParams.crm_user_id;
		var sugar_version = restParams.sugar_version;
		var crm_session_id = "";
		var params = [];
		
		params = [
			{
				name: 'crm_org_id',
				value: crm_org_id
			},
			{
				name:'crm_user_id',
				value: crm_user_id
			},
			{
				name: 'crm_org_name',
				value: crm_org_name
			},
			{
				name: 'crm_user_email',
				value: crm_user_email
			},
			{
				name: 'crm_deploy_id',
				value: crm_deploy_id
			},
			{
				name: 'crm_server_url',
				value: crm_server_url
			},
			{
				name: 'crm_version',
				value: crm_version
			},
			{
				name: 'crm_session_id',
				value: crm_session_id
			},
			{
				name: 'crm_size',
				value: crm_size
			},
			{
				name: 'crm_host_name',
				value: crm_host_name
			},
			{
				name: 'crm_token',
				value: thisRef.oauth
			},
			{
				name: 'user_type',
				value: app.user.get('type')
			},
			{
				name: 'appVersion',
				value: sugar_version
			},
			{
				name: 'solutionVersion',
				value: '1.0'
			}
		];

		return params;
	},
	
	getActionUrl: function(thisRef){
		var url = "",
			crm_context = thisRef.model.get("_module");
		switch (crm_context) {
			case "Accounts":
				url = "iv/crm/basic/company/analyze.iv";
				break;
			case "Contacts":
				url = "iv/crm/basic/executive/analyze.iv";
				break;
			case "Opportunities":
				url = "iv/crm/basic/company/analyze.iv";
				break;
			case "Leads":
				url = "iv/crm/basic/company/analyze.iv";
				break;
		}
		return url;
	},

	getModuleParams : function(thisRef, userParams) {
		var crm_context = thisRef.model.get("_module"),
			params=[];

		switch (crm_context) {
		case "Accounts":
			var crm_context = "account";
			var crm_account_name = thisRef.model.get('name');
			var crm_account_id = thisRef.model.get('id');
			var crm_account_ticker = thisRef.model.get('ticker_symbol');
			var crm_account_website = thisRef.model.get('website');
			var crm_account_city = thisRef.model.get('billing_address_city') ? thisRef.model
					.get('billing_address_city')
					: thisRef.model.get('shippping_address_city');
			var crm_account_state = thisRef.model.get('billing_address_state') ? thisRef.model
					.get('billing_address_state')
					: thisRef.model.get('shippping_address_state');
			var crm_account_postalcode = thisRef.model
					.get('billing_address_postalcode') ? thisRef.model
					.get('billing_address_postalcode') : thisRef.model
					.get('shippping_address_postalcode');
			var crm_account_country = thisRef.model
					.get('billing_address_country') ? thisRef.model
					.get('billing_address_country') : thisRef.model
					.get('shippping_address_country');

			params = [
				{
					name: 'crm_context',
					value: crm_context
				},
				{
					name: 'crm_account_id',
					value: crm_account_id
				},
				{
					name: 'crm_account_name',
					value: crm_account_name
				},
				{
					name: 'crm_account_ticker',
					value: crm_account_ticker
				},
				{
					name: 'crm_account_website',
					value: crm_account_website
				},
				{
					name: 'crm_account_city',
					value: crm_account_city
				},
				{
					name: 'crm_account_state',
					value: crm_account_state
				},
				{
					name: 'crm_account_postalcode',
					value: crm_account_postalcode
				},
				{
					name: 'crm_account_country',
					value: crm_account_country
				},
			];
			
			break;
		case "Contacts":
			var crm_context = "contact";
			var crm_object_id = thisRef.model.get('id');
			var crm_account_id = thisRef.model.get('account_id');
			var crm_account_name = thisRef.model.get('account_name');
			var crm_fn = thisRef.model.get('first_name');
			var crm_ln = thisRef.model.get('last_name');
			var crm_email = thisRef.model.get('email')
					&& thisRef.model.get('email')[0] ? thisRef.model
					.get('email')[0].email_address : "";
			var crm_title = thisRef.model.get('title');
			var crm_account_ticker = "";
			var crm_account_website = "";
			var crm_account_city = thisRef.model.get('primary_address_city') ? thisRef.model
					.get('primary_address_city')
					: thisRef.model.get('alt_address_city');
			var crm_account_state = thisRef.model.get('primary_address_state') ? thisRef.model
					.get('primary_address_state')
					: thisRef.model.get('alt_address_state');
			var crm_account_postalcode = thisRef.model
					.get('primary_address_postalcode') ? thisRef.model
					.get('primary_address_postalcode') : thisRef.model
					.get('alt_address_postalcode');
			var crm_account_country = thisRef.model
					.get('primary_address_country') ? thisRef.model
					.get('primary_address_country') : thisRef.model
					.get('alt_address_country');
				
			params = [
				{
					name: 'crm_context',
					value: crm_context
				},
				{
					name: 'crm_object_id',
					value: crm_object_id
				},
				{
					name: 'crm_fn',
					value: crm_fn
				},
				{
					name: 'crm_ln',
					value: crm_ln
				},
				{
					name: 'crm_title',
					value: crm_title
				},
				{
					name: 'crm_email',
					value: crm_email
				},
				{
					name: 'crm_account_id',
					value: crm_account_id
				},
				{
					name: 'crm_account_name',
					value: crm_account_name
				},
				{
					name: 'crm_account_ticker',
					value: crm_account_ticker
				},
				{
					name: 'crm_account_website',
					value: crm_account_website
				},
				{
					name: 'crm_account_city',
					value: crm_account_city
				},
				{
					name: 'crm_account_state',
					value: crm_account_state
				},
				{
					name: 'crm_account_postalcode',
					value: crm_account_postalcode
				},
				{
					name: 'crm_account_country',
					value: crm_account_country
				},
			];
			
			break;
		case "Opportunities":
			var crm_context = "opportunity";
			var crm_opportunity_id = thisRef.model.get('id');
			var crm_account_name = thisRef.model.get('account_name');
			var crm_account_id = thisRef.model.get('account_id');
			var crm_account_ticker = "";
			var crm_account_website = "";
			var crm_account_city = "";
			var crm_account_state = "";
			var crm_account_postalcode = "";
			var crm_account_country = "";
			
			params = [
				{
					name: 'crm_context',
					value: crm_context
				},
				{
					name: 'crm_account_id',
					value: crm_account_id
				},
				{
					name: 'crm_opportunity_id',
					value: crm_opportunity_id
				},
				{
					name: 'crm_account_name',
					value: crm_account_name
				},
				{
					name: 'crm_account_ticker',
					value: crm_account_ticker
				},
				{
					name: 'crm_account_website',
					value: crm_account_website
				},
				{
					name: 'crm_account_city',
					value: crm_account_city
				},
				{
					name: 'crm_account_state',
					value: crm_account_state
				},
				{
					name: 'crm_account_postalcode',
					value: crm_account_postalcode
				},
				{
					name: 'crm_account_country',
					value: crm_account_country
				},
			];
			break;
		case "Leads":
			var crm_context = "lead";
			var crm_lead_id = thisRef.model.get('id');
			var crm_lead_firstname = thisRef.model.get('first_name');
			var crm_lead_lastname = thisRef.model.get('last_name');
			var crm_lead_title = thisRef.model.get('title');
			var crm_lead_email = thisRef.model.get('email')
					&& thisRef.model.get('email')[0] ? thisRef.model
					.get('email')[0].email_address : "";
			var crm_account_id = thisRef.model.get('id');
			var crm_account_name = thisRef.model.get('account_name');
			var crm_account_website = thisRef.model.get('website');
			var crm_account_ticker = "";
			var crm_account_city = thisRef.model.get('primary_address_city') ? thisRef.model
					.get('primary_address_city')
					: thisRef.model.get('alt_address_city');
			var crm_account_state = thisRef.model.get('primary_address_state') ? thisRef.model
					.get('primary_address_state')
					: thisRef.model.get('alt_address_state');
			var crm_account_postalcode = thisRef.model
					.get('primary_address_postalcode') ? thisRef.model
					.get('primary_address_postalcode') : thisRef.model
					.get('alt_address_postalcode');
			var crm_account_country = thisRef.model
					.get('primary_address_country') ? thisRef.model
					.get('primary_address_country') : thisRef.model
					.get('alt_address_country');
			
			params = [
				{
					name: 'crm_context',
					value: crm_context
				},
				{
					name: 'crm_lead_id',
					value: crm_lead_id
				},
				{
					name: 'crm_lead_firstname',
					value: crm_lead_firstname
				},
				{
					name: 'crm_lead_lastname',
					value: crm_lead_lastname
				},
				{
					name: 'crm_lead_title',
					value: crm_lead_title
				},
				{
					name: 'crm_lead_email',
					value: crm_lead_email
				},
				{
					name: 'crm_account_id',
					value: crm_account_id
				},
				{
					name: 'crm_account_name',
					value: crm_account_name
				},
				{
					name: 'crm_account_ticker',
					value: crm_account_ticker
				},
				{
					name: 'crm_account_website',
					value: crm_account_website
				},
				{
					name: 'crm_account_city',
					value: crm_account_city
				},
				{
					name: 'crm_account_state',
					value: crm_account_state
				},
				{
					name: 'crm_account_postalcode',
					value: crm_account_postalcode
				},
				{
					name: 'crm_account_country',
					value: crm_account_country
				},
			];
			break;
		}

		return userParams.concat(params);

	},
	getUrl : function(params, thisRef) {
		var userParams = thisRef.getUserParams(thisRef, arguments[0]);
		var moduleParams = thisRef.getModuleParams(thisRef, userParams);
		return moduleParams;
	},

	_render : function() {
		if (!this.meta.config) {

			this.dashletConfig.view_panel[0].height = '340px';
			this.dashletConfig.view_panel[0].width = '99%';
			this.dashletConfig.view_panel[0].hasIv = true;
			this.dashletConfig.view_panel[0].iv = {
				'height': '99%',
				'width': '99%'
			}
		}
		var baseUrl = this.settings.get("baseurl");

		var endpointURL = app.config.siteUrl + app.config.serverUrl
				+ "/insideview/orgData";
		var thisRef = this;

		// console.debug(app.api.getOAuthToken());
		thisRef.oauth = app.api.getOAuthToken();

		app.api.call('GET', endpointURL, '', {
			success : function() {
				var url = thisRef.getActionUrl(thisRef);
				var params =  thisRef.getUrl(arguments[0], thisRef)
				if (!thisRef.meta.config) {
					thisRef.dashletConfig.view_panel[0].iv.params = params;
					thisRef.dashletConfig.view_panel[0].iv.url = baseUrl + url;
				}
				app.view.View.prototype._render.call(thisRef);
				if (thisRef.$el.find('#insideview-form')){
					thisRef.$el.find('#insideview-form').hide();
					thisRef.$el.find('#insideview-form').submit()
				}
			},
			error : function() {
				// console.log('in error');
				// console.log(arguments);
			}
		}, '');
	},

	initDashlet : function(view) {
		this.viewName = view;
		this.model.on('change:name', this.render, this);
		this.model.on('change:full_name', this.render, this);
	}
})
