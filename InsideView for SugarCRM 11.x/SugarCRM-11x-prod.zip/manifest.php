<?php
/*
 * ADD INSIDEVIEW COPYRIGHT HERE
 */

$manifest = array(
    'acceptable_sugar_versions' => array(
        'regex_matches' => array(
            '11\.[0123456789]*.\d\w*'
            ),
        ),
    'acceptable_sugar_flavors' => array(
        'PRO',
        'CORP',
        'ENT',
        'ULT',
        ),
    'readme' => '',
    'key' => '\\\'InsideView for Sales\\\'&#153;',
    'author' => '',
    'description' => '\\\'InsideView for Sales\\\'&#153; for SugarCRM 11',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => '\\\'InsideView for Sales\\\'&#153;',
    'published_date' => '2020-03-11 17:11:17',
    'type' => 'module',
    'version' => '1.0',
    'remove_tables' => false,
    );

$installdefs = array(
    'id' => 'insideview',
    'copy' => array(
        array(
			'from' => '<basepath>/dashlet/',
            'to' => 'custom/modules/Home/clients/base/views/insideview/',
            ),
			
			array(
				'from' => '<basepath>/endpoint/',
				'to' => 'custom/clients/base/api/',
			),
        ),
    'language' => array(
        array(
            'from' => '<basepath>/en_us.lang.php',
            'to_module' => 'application',
            'language' => 'en_us',
            ),
        ),
    );
?>