<?php
function pre_uninstall()
{
	global $current_user;

	require_once('include/utils.php');
	require_once('include/utils/file_utils.php');
	require_once('config.php');
	require_once('include/database/PearDatabase.php');

	require_once('include/MVC/Controller/SugarController.php');
	require_once('modules/ModuleBuilder/controller.php');
	require_once('modules/ModuleBuilder/parsers/ParserFactory.php');
	
	//Removing the html field from Accounts now.
	/************************************************************************************************/
	echo "<br> ************<strong> Deleting the SalesView mashup from Accounts module </strong>************** <br>";
	$account_field_name = 'insideview_account_c';

	$request_arr = array(
		'action' => 'DeleteField',
		'is_update' => 'true',
		'module' => 'ModuleBuilder',
		'view_module' => 'Accounts',
		'view_package' => 'studio',
		'type' => 'html',
		'name' => $account_field_name,
	);

	// $request_arr should now contain all the necessary information to create a custom field
	// merge $request_arr with $_POST/$_REQUEST, where the action_saveField() method expects them
	$_REQUEST = array_merge($_REQUEST, $request_arr);
	$_POST = array_merge($_POST, $request_arr);

	$mbc = new ModuleBuilderController();
	$mbc->setup();
	$mbc->action_DeleteField();

	//Successfully Deleted - now removing from the DetailView

	include('custom/modules/Accounts/metadata/detailviewdefs.php');

	// access the first panel in the DetailView viewdefs
	foreach ($viewdefs['Accounts']['DetailView']['panels'] as $panel_k => $panel) {
		foreach ($panel as $row_k => $row) {
			foreach ($row as $field_k => $field) {

				// we've found the field we just added
				if ($field['name'] == $account_field_name) {
					$viewdefs['Accounts']['DetailView']['panels'][$panel_k][$row_k][$field_k] = NULL;

					$str_to_write = '<?php $viewdefs = ';
					$str_to_write .= var_export($viewdefs, TRUE);
					$str_to_write .= ';?>';

					$fp = fopen('custom/modules/Accounts/metadata/detailviewdefs.php', 'wb');
					fwrite($fp, $str_to_write);
					fclose($fp);
				}
			}
		}
	}
	echo "<br>DONE<br><br>";
	
	//Removing the html field from Leads now.
	/************************************************************************************************/
	echo "<br> ************<strong> Deleting the SalesView mashup from Leads module </strong>************** <br>";
	
	$lead_field_name = 'insideview_lead_c';

	$lead_request_arr = array(
		'action' => 'DeleteField',
		'is_update' => 'true',
		'module' => 'ModuleBuilder',
		'view_module' => 'Leads',
		'view_package' => 'studio',
		'type' => 'html',
		'name' => $lead_field_name,
	);

	// $request_arr should now contain all the necessary information to create a custom field
	// merge $request_arr with $_POST/$_REQUEST, where the action_saveField() method expects them
	$_REQUEST = array_merge($_REQUEST, $lead_request_arr);
	$_POST = array_merge($_POST, $lead_request_arr);

	$leadMBC = new ModuleBuilderController();
	$leadMBC->setup();
	$leadMBC->action_DeleteField();

	//Successfully Deleted - now removing from the DetailView

	include('custom/modules/Leads/metadata/detailviewdefs.php');

	// access the first panel in the DetailView viewdefs
	foreach ($viewdefs['Leads']['DetailView']['panels'] as $panel_k => $panel) {
		foreach ($panel as $row_k => $row) {
			foreach ($row as $field_k => $field) {

				// we've found the field we just added
				if ($field['name'] == $lead_field_name) {
					$viewdefs['Leads']['DetailView']['panels'][$panel_k][$row_k][$field_k] = NULL;

					$str_to_write = '<?php $viewdefs = ';
					$str_to_write .= var_export($viewdefs, TRUE);
					$str_to_write .= ';?>';

					$fp = fopen('custom/modules/Leads/metadata/detailviewdefs.php', 'wb');
					fwrite($fp, $str_to_write);
					fclose($fp);
				}
			}
		}
	}
	echo "<br>DONE<br><br>";
		
	//Removing the html field from Opportunities now.
	/************************************************************************************************/
	echo "<br> ************<strong> Deleting the SalesView mashup from Opportunities module </strong>************** <br>";
	$Opportunities_field_name = 'insideview_opportunities_c';

	$Opportunities_request_arr = array(
		'action' => 'DeleteField',
		'is_update' => 'true',
		'module' => 'ModuleBuilder',
		'view_module' => 'Opportunities',
		'view_package' => 'studio',
		'type' => 'html',
		'name' => $Opportunities_field_name,
	);

	// $request_arr should now contain all the necessary information to create a custom field
	// merge $request_arr with $_POST/$_REQUEST, where the action_saveField() method expects them
	$_REQUEST = array_merge($_REQUEST, $Opportunities_request_arr);
	$_POST = array_merge($_POST, $Opportunities_request_arr);

	require_once('include/MVC/Controller/SugarController.php');
	require_once('modules/ModuleBuilder/controller.php');
	require_once('modules/ModuleBuilder/parsers/ParserFactory.php');

	$mbc = new ModuleBuilderController();
	$mbc->setup();
	$mbc->action_DeleteField();

	//Successfully Deleted - now removing from the DetailView
	
	include('custom/modules/Opportunities/metadata/detailviewdefs.php');

	// access the first panel in the DetailView viewdefs
	foreach ($viewdefs['Opportunities']['DetailView']['panels'] as $panel_k => $panel) {
		foreach ($panel as $row_k => $row) {
			foreach ($row as $field_k => $field) {

				// we've found the field we just added
				if ($field['name'] == $Opportunities_field_name) {
					$viewdefs['Opportunities']['DetailView']['panels'][$panel_k][$row_k][$field_k] = NULL;

					$str_to_write = '<?php $viewdefs = ';
					$str_to_write .= var_export($viewdefs, TRUE);
					$str_to_write .= ';?>';

					$fp = fopen('custom/modules/Opportunities/metadata/detailviewdefs.php', 'wb');
					fwrite($fp, $str_to_write);
					fclose($fp);
				}
			}
		}
	}
	echo "<br>DONE<br><br>";
	echo "<br> ***********************************************************************************************************<br>";
	echo "<br><strong> SalesView for Sugar has been successfully Uninstalled</strong>";
	echo "<br> ***********************************************************************************************************<br>";
	echo "<br> NOTE : Go to <strong>  Studio > Accounts/Leads/Opportunies > Layouts > DetailView </strong> to completely remove the the SalesView fields from the layout. Thanks! ";
	/************************************************************************************************/
}

?>
