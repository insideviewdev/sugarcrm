<?php
function pre_uninstall()
{
	global $current_user;

	require_once('include/utils.php');
	require_once('include/utils/file_utils.php');
	require_once('config.php');
	require_once('include/database/PearDatabase.php');

	require_once('include/MVC/Controller/SugarController.php');
	require_once('modules/ModuleBuilder/controller.php');
	require_once('modules/ModuleBuilder/parsers/ParserFactory.php');
	
	//Removing the html field from Accounts now.
	/************************************************************************************************/
	echo "<br> ************<strong> Removing InsideView from the Accounts module </strong>************** <br>";
	$account_field_name = 'insideview_account_c';

	require_once('modules/ModuleBuilder/Module/StudioModule.php');
    $sm = new StudioModule('Accounts');
    $sm->removeFieldFromLayouts($account_field_name);

	echo "<br>DONE<br><br>";
	
	//Removing the html field from Leads now.
	/************************************************************************************************/
	echo "<br> ************<strong> Removing InsideView from the Leads module </strong>************** <br>";
	
	$lead_field_name = 'insideview_lead_c';

	require_once('modules/ModuleBuilder/Module/StudioModule.php');
    $sm = new StudioModule('Leads');
    $sm->removeFieldFromLayouts($lead_field_name);

	echo "<br>DONE<br><br>";
		
	//Removing the html field from Opportunities now.
	/************************************************************************************************/
	echo "<br> ************<strong> Removing InsideView from the Opportunities module </strong>************** <br>";
	$Opportunities_field_name = 'insideview_opportunities_c';

	require_once('modules/ModuleBuilder/Module/StudioModule.php');
    $sm = new StudioModule('Opportunities');
    $sm->removeFieldFromLayouts($Opportunities_field_name);

	echo "<br>DONE<br><br>";
	echo "<br> ***********************************************************************************************************<br>";
	echo "<br><strong> InsideView for Sugar has been successfully Uninstalled</strong>";
	/************************************************************************************************/
}

?>
