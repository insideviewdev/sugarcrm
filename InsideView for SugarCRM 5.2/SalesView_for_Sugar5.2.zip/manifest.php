<?php
$manifest = array(
	'acceptable_sugar_versions' => array('*'),
	'name' => 'SalesView v47 for SugarCRM 5.2',
	'description' => 'Installs SalesView CRM into the Accounts, Leads & Opportunities detail pages.',
	'author' => 'InsideView Technologies',
	'published_date' => '2009/08/20',
	'version' => '47',
	'type' => 'module',
	'icon' => '',
	'is_uninstallable' => 'true',
);

$installdefs = array(
  'custom_fields' =>
  array (
    'Accountsinsideview_account_c' =>
    array (
      'id' => 'Accountsinsideview_account_c',
      'name' => 'insideview_account_c',
      'label' => 'LBL_SALESVIEW',
      'label_value' => 'SalesView',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Accounts',
      'type' => 'html',
      'max_size' => '45',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2008-06-10 00:00:00',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),
    'Leadsinsideview_lead_c' =>
    array (
      'id' => 'Leadsinsideview_lead_c',
      'name' => 'insideview_lead_c',
      'label' => 'LBL_SALESVIEW',
      'label_value' => 'SalesView',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Leads',
      'type' => 'html',
      'max_size' => '45',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2008-06-10 00:00:00',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    ),

    'Opportunitiesinsideview_lead_c' =>
    array (
      'id' => 'Opportunitiesinsideview_lead_c',
      'name' => 'insideview_opportunities_c',
      'label' => 'LBL_SALESVIEW',
      'label_value' => 'SalesView',
      'comments' => NULL,
      'help' => NULL,
      'module' => 'Opportunities',
      'type' => 'html',
      'max_size' => '45',
      'require_option' => '0',
      'default_value' => NULL,
      'date_modified' => '2008-06-10 00:00:00',
      'deleted' => '0',
      'audited' => '0',
      'mass_update' => '0',
      'duplicate_merge' => '0',
      'reportable' => '1',
      'ext1' => NULL,
      'ext2' => NULL,
      'ext3' => NULL,
      'ext4' => NULL,
    )
  ),
);

?>
